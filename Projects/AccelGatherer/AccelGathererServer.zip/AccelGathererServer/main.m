//
//  main.m
//  AccelGathererServer
//
//  Created by Jonathan Wight on 8/26/08.
//  Copyright toxicsoftware.com 2008 . All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **) argv);
}
